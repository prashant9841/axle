
	</div>
	<footer class="page-footer">
		<div class="row">
			<div class="s12 m5 col">
				<p class="left">&copy; copyright reserved 2016</p>
				<ul class="left social">
					<li><a href="#"><i class="fa fa-facebook"></i></a></li>
					<li><a href="#"><i class="fa fa-facebook"></i></a></li>
					<li><a href="#"><i class="fa fa-facebook"></i></a></li>
					<li><a href="#"><i class="fa fa-facebook"></i></a></li>
				</ul>
			</div>
			<div class="s12 m7 col">
				<ul class="footer-nav right">
					<li><a href="#">Home</a></li>
					<li><a href="#">About us</a></li>
					<li><a href="#">News</a></li>
					<li><a href="#">Portfolio</a></li>
					<li><a href="#">Services</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
			</div>
		</div>
	</footer>

	<!-- scripts	 -->
	<script src="js/jquery.js"></script>
	<script src="js/jquery.mixitup.js"></script>
	<script src="js/aminateSlider.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/slick.js"></script>
	<script src="js/custom.js"></script>
</body>
</html>