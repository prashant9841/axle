
	<footer class="page-footer">
		<div class="row">
			<div class="s12 m5 col">
				<p class="left">&copy; copyright reserved 2016</p>
				<ul class="left social">
					<li><a href="#"><i class="fa fa-facebook"></i></a></li>
					<li><a href="#"><i class="fa fa-facebook"></i></a></li>
					<li><a href="#"><i class="fa fa-facebook"></i></a></li>
					<li><a href="#"><i class="fa fa-facebook"></i></a></li>
				</ul>
			</div>
			<div class="s12 m7 col">
				<ul class="footer-nav right">
					<li><a href="index.php">Home</a></li>
					<li><a href="about.php">About us</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="portfolio.php">Portfolio</a></li>
					<li><a href="blog.php">Blog</a></li>
					<li><a href="contact.php">Contact</a></li>
				</ul>
			</div>
		</div>
	</footer>

	<!-- scripts	 -->
	<script src="js/jquery.js"></script>
	<script src="js/jquery.mixitup.js"></script>
	<script src="js/aminateSlider.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/slick.js"></script>
	<script src="js/particles.js"></script>
	<script src="js/lettering.js"></script>
	<script src="js/textillate.js"></script>
	<script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAujn52Zl9Aqn2HoDVlEeSSr_RH5QeLhDw&callback=initMap">
    </script>
	</script>
	<script src="js/gmaps.js"></script>
	<script src="js/custom.js"></script>
</body>
</html>